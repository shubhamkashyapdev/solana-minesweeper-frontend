import express from "express";
import { startMatching } from "../controllers/findOpponent.controller";
const router = express.Router();

router.post("/findOpponent", startMatching);

export default router;
